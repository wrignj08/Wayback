Wayback is a simple chrome extension which when clicked will load up the Internet Archive version of the current tab.
![alt text](https://raw.githubusercontent.com/wrignj08/Wayback/main/Screen%20Shots/Screen%20Shot%201.png)
